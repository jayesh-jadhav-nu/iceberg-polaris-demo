# ShopCo lakehouse demo: step-by-step guide

Everything runs with `./run.sh <step>` from the `demo-kit` folder. Each step below gives the command, what the output looks like, what to say, and what to point at.

Tested end to end on 2026-11-24 with `apache/polaris` 1.9.0, `tabulario/spark-iceberg` (Spark 3.5, Iceberg 1.8.1), `trinodb/trino:latest` and `rustfs/rustfs` 1.0.1 on Linux x86 with Docker 29. Numbers in the sample outputs come from that run; yours will differ.

Time: about 15 minutes of setup before the session, 25 to 30 minutes live.

---

## 0. Before you start

### Install what you need (once)
1. **Docker Desktop**, running, with at least 10 GB of memory: Docker Desktop → Settings → Resources → Memory. The images total about 13 GB on disk.
2. **`curl` and `jq`** for the setup script. On a Mac: `brew install jq` (`curl` is already there).

Check:
```bash
docker info | grep -E "Total Memory|Server Version"
jq --version
```

### Unpack the kit
Download `shopco-demo-kit.tar.gz`, then in a terminal:
```bash
cd ~/Downloads            # or wherever the .tar.gz landed
tar xzf shopco-demo-kit.tar.gz
cd demo-kit
chmod +x run.sh polaris-setup.sh demo/*.sh
./run.sh                  # prints the list of steps; no arguments = help
```
Every command in this guide is run from inside this `demo-kit` folder.

On a Mac, if Docker complains about `platform`, nothing to do: all five images have ARM builds. If a browser link in this guide doesn't open, replace `localhost` with `127.0.0.1`.

**Folder layout:**
```
demo-kit/
  run.sh                 one command per step (use this)
  polaris-setup.sh       called by run.sh; creates catalog, roles, principals via the Polaris REST API
  docker-compose.yml     the five containers
  spark/, trino/         engine config templates; run.sh setup fills them with real secrets
  demo/                  the SQL and Python for each step; open them to show the code on screen
  secrets/               created by setup: one client_id:secret per principal
  DEMO_GUIDE.md          this file
```

**The five containers:**

| Container | What it is | In the story |
|---|---|---|
| `rustfs` | S3-compatible object store with an STS endpoint; file browser at http://localhost:9001 (admin / password) | Amazon S3 + STS |
| `createbucket` | Runs once, creates the `shopco-lake` bucket, exits | The bucket |
| `polaris` | Apache Polaris, the Iceberg REST catalog, at http://localhost:8181 | Polaris |
| `spark` | Spark SQL with the Iceberg runtime, plus PyIceberg | Data engineering engine and the streaming writer |
| `trino` | Trino, at http://localhost:8090 | The BI analysts' engine |

**How credentials flow (this is real, not simulated):** no engine has S3 keys in its config. An engine asks Polaris for a table with `X-Iceberg-Access-Delegation: vended-credentials`. Polaris checks the grant, then calls RustFS's STS `AssumeRole` with a session policy limited to that table's prefix and the privileges the caller holds (read only for `reader`), and returns the temporary keys. You can see this on the wire in Step 14, and you see its effect when Trino's DELETE is refused by storage in Step 9.

**Principals that `setup` creates in Polaris:**

| Principal | Role chain | Can |
|---|---|---|
| `spark_etl` | pipelines → engineer | Everything in the catalog (create, write, maintain) |
| `ci_deployer` | pipelines → engineer | Same; stands for the CI system, unused in the demo |
| `flink_stream` | streaming → stream_writer | Write data into `raw` only (unused: the demo stream runs inside Spark as `spark_etl`) |
| `trino_bi` | analytics → reader | Read `curated` only |
| `ds_notebook` | data_science → reader + ds_extra | Read `curated` plus the one table `pii.customers` |
| `alice` | data_eng → catalog_reader | Read everything, write nothing (a human engineer) |

---

## Part 1: Setup (before the session, ~15 min)

### Step 1-2: start storage and Polaris
```bash
./run.sh up
```
**Expect:** three containers start, "Polaris is ready" after 20-60 s, and `make_bucket: shopco-lake`. Open http://localhost:9001 (admin / password): an empty `shopco-lake` bucket.

**If it fails:** `docker compose logs polaris`. The first run pulls images; give it time.

### Step 3-4: create the catalog, roles and principals
```bash
./run.sh setup
```
This script talks to Polaris's management REST API with `curl`. **Expect** sections like:
```
== Get an admin token (OAuth client credentials)
== Step 3: create the catalog 'retail' at s3://shopco-lake/retail
{"type":"INTERNAL","name":"retail", ... "storageConfigInfo":{"endpoint":"http://rustfs:9000","stsEndpoint":"http://rustfs:9000","pathStyleAccess":true, ...}}
== Step 4a: catalog roles
{"name":"engineer", ...}  {"name":"catalog_reader", ...}  ...
== Step 4b: catalog-level grants            <- blank lines are 204 No Content = success
== Step 4c: principal roles and which catalog roles they hold
== Step 4d: principals (one per service) and their secrets
  ci_deployer -> pipelines  (secret saved to secrets/ci_deployer.credential)
  spark_etl -> pipelines
  ...
== Fill engine configs from templates
  wrote spark/spark-defaults.conf and trino/retail.properties
```
**Worth showing live if you have time:** scroll up and point at the token call, `POST /catalogs`, the roles, and the `secrets/` folder. That's "Management API" and "OAuth" in one screen.

**If it fails:** `{"error":{"message":"...already exists"}}` means you ran it twice; harmless. Anything else: `./run.sh reset` and start over.

### Start the engines
```bash
./run.sh engines
```
**Expect:** "Spark is ready" (~60 s), "Trino is ready" (~60-90 s). Both read the configs `setup` wrote, so they log in to Polaris as `spark_etl` and `trino_bi`.

### Step 5: create the tables
```bash
./run.sh 5
```
**Expect:** no errors, then a long `DESCRIBE TABLE EXTENDED` ending in table properties. It also seeds 50 customers.

**Point at:** in `demo/05_create_tables.sql`, `PARTITIONED BY (day(order_ts))` and `write.merge.mode = merge-on-read`. In the output, `# Partitioning  Part 0  days(order_ts)`.

**If it fails with "Forbidden":** `spark/spark-defaults.conf` must contain a real `client_id:secret`; then `docker compose restart spark`.

### Step 4 (part 2): namespace- and table-level grants
```bash
./run.sh grants
```
Polaris can't grant on a namespace or table that doesn't exist yet, so this runs after Step 5. **Expect:** blank lines (204s) and a JSON listing of the `reader` role's grants.

### Step 6: start the streaming writer
```bash
./run.sh 6
```
A Spark Structured Streaming job starts in the background and commits a batch of fake orders every 30 s. **Leave it running** through Step 11. After ~90 s:
```bash
./run.sh snapshots
```
**Expect** rows 30 s apart:
```
2026-11-24 08:45:00.991   append   150
2026-11-24 08:44:31.914   append   115
2026-11-24 08:44:11.433   append   NULL      <- first, empty batch
```
If nothing appears after 2 minutes: `docker compose logs spark | tail -50`.

**Setup done.** Leave everything running. Polaris keeps its state in memory, so `docker compose down` means starting from Step 1 again (15 min).

---

## Part 2: Live demo (~25 min)

Every step prints the same way, so the audience can follow without reading code:

```
==============================================================================
  Step N: <what we are doing>
  demonstrates: <capabilities>
==============================================================================
--- BEFORE -------   the state before the action, as a few labelled numbers
>>> ACTION: ...      the statement(s) being run
--- AFTER --------   the same numbers again
*** WHAT CHANGED:    one sentence tying the difference to the capability
*** UNCHANGED:       when "nothing changed" is the point (no files rewritten, main untouched)
```

Keep a terminal in `demo-kit` and a browser tab on http://localhost:9001.

### Opening (1 min)
```bash
./run.sh status
./run.sh snapshots
```
**Say:** "Five containers on my laptop. A streaming job has been writing orders for a while; a new snapshot every 30 seconds. No engine has S3 keys in its config; they all go through Polaris."

**Theory and likely questions**
- *What is a snapshot?* The complete list of files that make up the table at one commit. The stream's `append` every 30 s writes one new Parquet file, one manifest, one manifest list and one new `metadata.json`, then asks Polaris to move the table pointer. Readers that started before the commit keep the old list; nobody sees a half-written batch.
- *Why does `metadata/` keep growing?* Every commit writes a new `0000N-….metadata.json` (schema, partition specs, full snapshot history), so each is slightly larger than the last. `write.metadata.previous-versions-max=50` caps how many old ones are kept, and `expire_snapshots` (Step 13) removes the manifests and data files only old snapshots reference.
- *Where are the keys?* Polaris holds the storage identity. Each engine logs in with its own client id and secret (OAuth), asks Polaris for a table, and gets short-lived keys scoped to that table. `secrets/` holds the client secrets; no S3 key appears in any engine config.

**Browser (30 s):** `localhost:9001` → `shopco-lake/retail/raw/orders/data/`, refresh twice: a new Parquet file per commit.

### Where to show the raw files
Open http://localhost:9001 (admin / password) → `shopco-lake` → `retail` → `raw` → `orders`. Two moments are worth 30 seconds each; skip it elsewhere so the demo keeps moving.

| After | Look at | Point to make |
|---|---|---|
| Opening (stream running) | `raw/orders/data/order_ts_day=…/` and `raw/orders/metadata/` | Refresh twice: a new Parquet file and a new `0000N-….metadata.json` every 30 s. Every commit is new files; nothing is edited in place. |
| Step 13 | `raw/orders/data/` next to `./run.sh sql` → `SELECT file_path FROM retail.raw.orders.files;` | The bucket still holds the small files compaction replaced; Iceberg's own list has only the compacted ones. The table is the metadata, not the folder. |

Optional, after Step 8: old files under `order_ts_day=…/`, new ones from the stream under `…/order_ts_hour=…/`, both layouts side by side. Step 15 prints the `daily_sales` listing from the terminal.

### Step 7: Publish the nightly numbers safely (5 min)
```bash
./run.sh 7
```
**Expect:**
```
--- BEFORE the nightly job
    main: rows / snapshot              0 / none yet          <- fresh table (on a rerun: 5 / <older id>)
    audit: rows / snapshot             0 / none yet
    raw.orders snapshots (the stream)  5
>>> ACTION: SET spark.wap.branch = audit; MERGE INTO curated.daily_sales ...
--- AFTER the MERGE, before publishing
    main: rows / snapshot              0 / none yet          <- main did not move
    audit: rows / snapshot             5 / 7465018987067631320
*** UNCHANGED: main did not change. Anyone reading main still sees the old numbers.
*** WHAT CHANGED: The new numbers exist only on the audit branch.
>>> ACTION: AUDIT the branch: three checks
    rows with negative revenue         0
    rows with null sale_date           0
    <the 5 rows on the branch>
    checks passed                      True
>>> ACTION: PUBLISH: CALL fast_forward('main', 'audit')
--- AFTER publish
    main: rows / snapshot              5 / 7465018987067631320    <- same id as audit now
*** WHAT CHANGED: main now has the checked numbers. Spark, Trino and PyIceberg all see them from now on.
    raw.orders snapshots now           6  (+1 committed by the stream during this job, no conflict)
```
**Say:** "The job wrote to a branch. Main didn't move, so nobody downstream saw anything. The checks ran against the branch and passed, so we fast-forwarded main: a pointer move, instant. If a check had failed we'd stop right there. And the stream kept committing to the same catalog meanwhile; two writers, no conflict."

**Theory and likely questions**
- *When does the MERGE happen?* Only when you run `./run.sh 7` (the "nightly job"). Nothing merges on its own: the stream only appends to `raw.orders`, so `daily_sales` goes stale until the job runs again. A rerun recomputes and updates the same 5 `(sale_date, country)` rows, which is why a second run shows 5 rows again with a new snapshot.
- *What does the MERGE write?* `daily_sales` is copy-on-write, so the MERGE writes one new Parquet file holding the 5 current rows, a manifest listing it, a manifest marking the old file as removed, a manifest list, and a new `metadata.json`. The old Parquet file stays until snapshot expiry. That is why `metadata/` grows by a few files per commit.
- *What is a branch here?* A named pointer to a snapshot, like `main`. With `spark.wap.branch = audit`, writes commit to that pointer; `main` is untouched. `fast_forward` sets `main` to `audit`'s snapshot: no data moves. A rollback (Step 11) is the same mechanism in the other direction.
- *Why did the stream not conflict with the MERGE?* They write different tables. Two writers on the *same* table would both try to move its pointer; Polaris accepts the first and rejects the second, which retries on top of the new snapshot (optimistic concurrency). The demo shows the catalog serving two writers; a retry is not visible unless you force a collision.
- *Why does the status breakdown matter?* It shows the job's logic doing something: 45 CANCELLED orders exist in `raw.orders` and the branch's `orders` total equals the PAID count, not the total.

```bash
./run.sh 7b
```
**Expect:** `rows in the whole table 720`, then `rows in that range 300`, then the `.refs` table with `etl_processed TAG`. **Say:** "Only the slice since last time, and a tag bookmarks where to start next."

### Step 8: Change a live table without rewriting it (3 min)
```bash
./run.sh 8
```
**Expect:**
```
--- BEFORE
    columns          order_id bigint, customer_id bigint, amount decimal(10,2), status string, order_ts timestamp
    partitioned by   days(order_ts)
    data files       5
>>> ACTION: ADD COLUMN coupon_code string; ALTER COLUMN amount TYPE decimal(12,2); RENAME COLUMN coupon_code TO promo_code; REPLACE PARTITION FIELD ...
--- AFTER
    columns          ..., amount decimal(12,2), status string, order_ts timestamp, promo_code string
    partitioned by   hours(order_ts)
    data files       5  (before: 5; any difference is the stream committing meanwhile)
    <5 old rows with promo_code NULL>   <partition specs: spec_id 0, and 1 once the stream writes>
*** WHAT CHANGED: The table has 6 columns instead of 5: coupon_code was added and then renamed to promo_code, amount was widened. New data is split by hour instead of by day.
*** UNCHANGED: No data file was rewritten. Old rows show NULL for promo_code and stay in their daily folders.
--- WHERE THE CHANGE LIVES, PHYSICALLY
    column ids inside each data file   old files: [1, 2, 3, 4, 5]   new files: [1, 2, 3, 4, 5, 6]   (promo_code is id 6)
    metadata.json BEFORE this step     00007-….metadata.json   schema: order_id, customer_id, amount, status, order_ts (spec 0)
    metadata.json AFTER this step      00011-….metadata.json   schema: ..., status, order_ts, promo_code (spec 1)
    an old data file                   order_ts_day=…/…parquet   columns inside: order_id, customer_id, amount, status, order_ts
    a new data file                    order_ts_hour=…/…parquet  columns inside: ..., status, order_ts, promo_code
```
The step restarts the stream before showing the new file: a running streaming writer keeps the schema and partition spec it started with (a Flink job would too), so the first hourly, six-column file only appears after a restart. That wait is about a minute; use it to show the browser.
**Say:** "Four changes a Hive table would need a rewrite for. Same number of data files before and after. The change is four new `metadata.json` files; the old Parquet files still have five columns, and the next file the stream writes has six."

**Theory and likely questions**
- *Why is no data rewritten?* Iceberg names columns by an integer id inside every Parquet file's schema mapping. A rename changes the name attached to id 6; the files are untouched. An added column is a new id that old files simply lack, so they return NULL for it. Widening `decimal(10,2)` to `(12,2)` is an allowed promotion; narrowing is not.
- *How can two partition layouts coexist?* Each data file records which partition spec it was written with (`spec_id`). Planning applies the right transform per spec, so a filter on `order_ts` prunes daily files by day and hourly files by hour. Old files are never moved.
- *So is the new column in the data files?* Only in files written after the change. The ADD COLUMN wrote a new `metadata.json` with field id 6 (named `coupon_code`, then `promo_code`); old Parquet files carry ids 1-5 in their footers and simply lack it, so readers fill NULL. The bottom of the step prints both: the footer ids per file, and the column list read from one old and one new Parquet file through Iceberg's own IO. (`SELECT * FROM parquet.\`s3://…\`` does not work in this image: Spark has no Hadoop S3 filesystem; only Iceberg's FileIO reaches the bucket.)
- *What can't you change?* Type changes that lose information (string to int). And one practical rule: do not rename a column that a running writer is still writing. Iceberg matches an incoming DataFrame to the table by column name, so the writer's next batch fails with `Field status not found in source schema`. That is why this step renames the new column, not `status`. Partition evolution never rewrites old files; if you want the new layout everywhere, run compaction with a sort.

### Step 9: Query as the analyst (4 min)
```bash
./run.sh 9
```
**Expect**, first Spark: BEFORE shows no views, AFTER shows `weekly_sales` and its rows. Then Trino, one block per statement:
```
>>> SELECT country, sum(revenue) ... FROM curated.daily_sales
    expect: OK: reader may read curated; Polaris vends read-only keys for it
    RESULT: OK   <5 rows>
>>> SHOW SCHEMAS                       RESULT: OK   curated, information_schema, pii, raw, system
>>> SHOW TABLES FROM curated           RESULT: OK   daily_sales, weekly_sales
>>> SELECT * FROM curated.weekly_sales
    expect: REFUSED by Trino: the view only has a Spark-dialect SQL representation
    RESULT: REFUSED -> Cannot read unsupported dialect 'spark' for view 'curated.weekly_sales'
>>> SELECT email FROM pii.customers
    expect: REFUSED by Polaris: no grant on pii -> 403, no credentials vended
    RESULT: REFUSED -> Failed to load table 'customers'
>>> DELETE FROM curated.daily_sales WHERE country = 'DE'
    expect: REFUSED by storage: Polaris vended read-only keys, so the Parquet write gets AccessDenied
    RESULT: REFUSED -> Error committing write to Parquet file
*** WHAT THIS SHOWS: one identity, three outcomes. curated data came back. pii was refused by Polaris before any key was handed out. The DELETE was refused by storage, because the keys were read-only.
```
**Say:** each `expect:` line is the talking point; read it before the result lands. **Point at:** `trino/retail.properties`, no S3 key in it.

**Theory and likely questions**
- *Three refusals, three mechanisms.* The view fails inside Trino: Iceberg views store SQL per dialect and Spark only wrote a Spark one. `pii.customers` fails in Polaris: no grant, so `loadTable` returns 403 and no credentials, and Trino never contacts storage. The `DELETE` fails in storage: Polaris granted `TABLE_READ_DATA` only, so the vended STS session policy allows `GetObject` and not `PutObject`, and RustFS answers `AccessDenied` on the Parquet write.
- *Why can Trino list `pii` and `raw` in `SHOW SCHEMAS`?* `NAMESPACE_LIST` at catalog level reveals namespace names only. Remove that grant if even the names are sensitive; `SHOW SCHEMAS` then fails for the reader.
- *Could the view be made to work in Trino?* Yes, by adding a Trino SQL representation to the same view (Trino can `CREATE VIEW` in the REST catalog with the right grant), or by materialising it as a table in the nightly job.

### Step 10: Pin the training data (3 min)
```bash
./run.sh 10
```
**Expect:** BEFORE refs without the tag; ACTION creates `model_v3_training RETAIN 365 DAYS`; AFTER refs with the tag and `rows at the tag 5`. Then PyIceberg: `RESULT: OK, training rows: 5`, `RESULT: OK, customers: 50`, `RESULT: REFUSED -> ForbiddenError ... 'ds_notebook'`.

**Say:** "A name pinned to today's snapshot, protected for a year. Despite whatever gets written to the table after this, reading it by that name gives exactly these rows. Python reads it with no Spark, gets exactly one PII table, and nothing else."

**Theory and likely questions**
- *What does "despite whatever gets written later" mean?* Right after Step 10 all refs point at the same snapshot. From then on every write moves `main` to a new snapshot; the tag stays on this one. To show it: note `sum(revenue)` on `main` and `VERSION AS OF 'model_v3_training'` (equal now), run Step 11 and then Step 7 again (main gets new snapshots), and compare again: `.refs` shows main on a newer snapshot id, the tag on the old one; the tag's sum is unchanged.
- *Tag versus branch?* Both are named pointers in `.refs`. A tag is immutable (a bookmark); a branch moves as you commit to it. Both keep their snapshot, and the files it references, alive through `expire_snapshots` until their retention passes.
- *Why PyIceberg?* To show a third engine with no JVM: the same REST login, the same vended credentials, the same table-level grant check. Anything that speaks the Iceberg REST protocol is a peer of Spark and Trino.
- *What happens in a year?* The tag's `RETAIN 365 DAYS` expires; the next `expire_snapshots` can drop the snapshot and its files, and the model's training set is no longer reproducible. Set retention to the model's lifetime.

### Step 11: Undo a bad job (2 min)
```bash
./run.sh 11
```
**Expect:**
```
--- BEFORE          revenue_before 81627.87    main snapshot 1495...
>>> ACTION: the 2 a.m. bug: UPDATE curated.daily_sales SET revenue = 0
--- AFTER the bug   revenue_after_bug 0.00     main snapshot 5791...    <3-row history>
>>> ACTION: CALL rollback_to_snapshot('curated.daily_sales', 1495...)
--- AFTER rollback  revenue_restored 81627.87  main snapshot 1495...
*** WHAT CHANGED: main points at the good snapshot again. Revenue went 81627.87 -> 0 -> 81627.87. No data was copied.
```

**Theory and likely questions**
- *Is the bad snapshot gone?* No. Rollback moves `main` back to an older snapshot; the bad one stays in `.snapshots` (and its files in the bucket) until expiry. You could even roll forward to it again. That is also why rollback is instant.
- *What about readers mid-rollback?* Each query reads one snapshot for its whole duration. A query started before the rollback finishes on the bad snapshot; the next one sees the good one.

### Step 12: Forget a customer (2 min)
```bash
./run.sh 12
```
Stops the stream first. **Expect:**
```
--- BEFORE   customer to forget 42   their rows in raw.orders 20   files: data / delete  7 / 0
>>> ACTION: DELETE FROM pii.customers ...; DELETE FROM raw.orders WHERE customer_id = 42
--- AFTER    their rows in raw.orders 0   files: data / delete  7 / 7   their rows in the previous snapshot 20
*** WHAT CHANGED: Queries now return 0 rows for customer 42. But the DELETE only added 7 small delete files. The data files are untouched, and the previous snapshot still returns all 20 rows.
```
**Say:** "Hidden, not gone. The purge is the maintenance job."

**Theory and likely questions**
- *Why delete files?* `raw.orders` is merge-on-read. A DELETE writes small position-delete files ("skip row 17 of file X") instead of rewriting the data files, so deletes are cheap next to a stream that keeps adding files. Readers apply the delete files on the fly; compaction folds them in later. Copy-on-write (used by `daily_sales`) rewrites the affected data files instead: slower writes, faster reads.
- *Why is this not enough for GDPR?* Three things still hold the rows: the untouched data files, the previous snapshot, and any tag or branch pinning that snapshot. Step 13 removes the first two; a real purge also drops old tags.

### Step 13: Maintenance, which is the purge (3 min)
```bash
./run.sh 13
```
**Expect:**
```
--- BEFORE   data files / avg KB 7 / 2.7   delete files 7   snapshots 9   refs etl_processed (TAG), main (BRANCH)
>>> ACTION: rewrite_data_files (rewrite-all) · rewrite_position_delete_files · rewrite_manifests · expire_snapshots · remove_orphan_files (skipped on this image)
--- AFTER    data files / avg KB 2 / 5.0   delete files 1   snapshots 2   refs etl_processed (TAG), main (BRANCH)
*** WHAT CHANGED: Files: 7 data + 7 delete -> 2 data + 1 delete. Snapshots: 9 -> 2. The deleted customer's rows are no longer in any file the table can reach.
    The tag above keeps its snapshot alive. To finish a purge, drop old tags too.
```
**Say:** "Compaction merged the files and applied the deletes, expiry removed the old ones. The one tag is what keeps the second snapshot, and its delete file, alive."

**Theory and likely questions**
- *What each procedure does.* `rewrite_data_files` reads data files plus their delete files and writes fewer, larger files with the deletes applied. `rewrite_position_delete_files` drops delete files that no longer apply. `rewrite_manifests` regroups manifests so planning reads fewer of them. `expire_snapshots` removes snapshots older than a timestamp (keeping at least `retain_last`) and deletes every file that only those snapshots referenced. `remove_orphan_files` lists the bucket and deletes files no snapshot knows about (failed writes, replaced files whose snapshots expired).
- *Why are there still files in the bucket after this?* Files replaced by compaction are deleted when the snapshot that referenced them expires, and orphans only by `remove_orphan_files`, which this image's Iceberg can't run against S3. The browser shows the bucket; `./run.sh files` shows what the table actually references.
- *How often in production?* Compaction hourly on recent partitions, daily snapshot expiry keeping a few days, weekly manifest rewrite and orphan cleanup; tune per table by commit rate and file counts.

**Browser (30 s):** `raw/orders/data/` still shows the small files; `./run.sh sql` → `SELECT file_path FROM retail.raw.orders.files;` shows only the compacted ones. The table is the metadata, not the folder.

### Steps 14 and 15: the keys on the wire, and the files in the bucket (3 min)
```bash
./run.sh A
./run.sh B
```
Step 14 prints the allowed `loadTable` with `s3.access-key-id`, `s3.secret-access-key`, `s3.session-token` and an expiry, then the refused one: `not authorized for op LOAD_TABLE_WITH_READ_DELEGATION`, `HTTP 403`. Step 15 lists `metadata/0000N-….metadata.json`, `snap-*.avro`, `*-m0.avro` and the Parquet files.

**Theory and likely questions**
- *What exactly does Polaris do on an allowed `loadTable`?* Checks the caller's grants, calls STS `AssumeRole` (RustFS's endpoint here, AWS's in production) with a session policy limited to the table's prefix and the caller's privileges, and returns the temporary key, secret and session token with the metadata location. The engine uses them directly against storage; Polaris is not in the data path.
- *What is in `metadata/`?* `0000N-….metadata.json` per commit (schema, specs, snapshot log, current snapshot id), `snap-<id>-….avro` per snapshot (the manifest list), `<uuid>-mN.avro` manifests (data and delete files with per-column stats), and in `data/` the Parquet files under partition folders. The catalog stores only the pointer to the current `metadata.json`.

### Step 16: Two writers, one table (3 min)
```bash
./run.sh 16
```
Deterministic, no timing: writer A (PyIceberg) prepares an append and holds it; writer B (Spark) commits an INSERT to the same table; writer A then tries to commit on its stale base. **Expect:**
```
--- BEFORE   current snapshot (both writers read this) 2795…   rows 25
>>> ACTION: Writer A (PyIceberg) prepares an append of 10 rows against that snapshot, but does not commit yet
>>> ACTION: Writer B (Spark) commits an INSERT of 5 rows to the same table first
    table snapshot now   4968…  (moved by writer B)
>>> ACTION: Writer A now tries to commit its append, still based on the old snapshot
    result   REJECTED by Polaris: CommitFailedException: Requirement failed: branch main has changed: expected id 2795…
>>> ACTION: Writer A reloads the table and commits the same append on top of writer B's snapshot (the retry)
    result   committed
--- AFTER    table snapshot now 3875…  (moved again, by writer A's retry)   rows 40  (+5 from B, +10 from A)
    <last three snapshots: A's retry (parent = B's), B's (parent = the original), the original>
*** WHAT CHANGED: Both writers' rows are in the table. Writer B's commit landed first; writer A's first attempt was refused because the table had moved, and its retry committed on top of B. No lock, no lost update, no corruption.
```
**Say:** "This is what Step 7 only talked about. Two writers on the same table. Each commit says 'I expect main to be at snapshot X'. Polaris applies the first, refuses the second with exactly that message, and the writer retries on the new snapshot. Spark and Flink do this retry for you silently; PyIceberg makes it visible, which is why I use it here."

**Theory and likely questions**
- *Why no lock?* Writers never block each other; they only race at the final pointer swap, which Polaris makes atomic. A loser re-reads and retries, usually in milliseconds. Iceberg's Java library retries up to 4 times by default (`commit.retry.num-retries`).
- *Can a retry lose data?* No. The retry re-applies the same change on the new snapshot. For appends there is nothing to check. For row-level changes (MERGE, DELETE), the retry validates that the files it rewrote were not touched by the other commit; if they were, it fails for real rather than overwrite, and the job must rerun.
- *What is "Requirement failed"?* The REST commit carries requirements such as `assert-ref-snapshot-id: main = 2795…`. Polaris checks them atomically on the table entry and rejects on mismatch. That one check is the whole concurrency control.

---

## Capability index: command, then what to show

### Iceberg (12)

| Capability | Command | Show this |
|---|---|---|
| ACID transactions | `./run.sh snapshots` (stream running), then `./run.sh 7` | Timestamps 30 s apart; the WAP job commits while the stream keeps appending |
| Time travel, rollback | `./run.sh 10`, `./run.sh 11`, `./run.sh 12` | `rows_at_tag`; `revenue_before` = `revenue_restored`; `rows_in_previous_snapshot 42` after the delete |
| Schema evolution | `./run.sh 8` | `data_files_before` = `data_files_after`; `coupon_code NULL`; `order_status` renamed; `amount decimal(12,2)` |
| Hidden partitioning | `./run.sh 5` | `# Partitioning  days(order_ts)`; every later query filters on `order_ts`, never on a partition column |
| Partition evolution | `./run.sh 8` | `.partitions` row with `order_ts_hour`; DESCRIBE shows `hours(order_ts)` |
| Row-level changes | `./run.sh 7` (MERGE), `./run.sh 12` (DELETE) | MERGE on the branch; `files: data / delete  7 / 7` after the DELETE |
| Branches and tags | `./run.sh 7`, `./run.sh 10` | `.refs`: `audit BRANCH`, `main BRANCH`, `model_v3_training TAG`, `etl_processed TAG` |
| Multi-engine access | `./run.sh 9`, `./run.sh 10` | Spark wrote it; Trino returns rows; PyIceberg prints a pandas frame. Same files, three engines |
| Incremental reads | `./run.sh 7b` | `rows in that range: 300` vs `rows in the whole table: 715` |
| Metadata tables | `./run.sh 7`, `11`, `12`, `13` | `.snapshots`, `.refs`, `.files`, `.partitions` |
| Maintenance procedures | `./run.sh 13` | `files 7 data + 7 delete -> 2 data + 1 delete; snapshots 9 -> 2` |
| Views | `./run.sh 9` | Spark: `SHOW VIEWS` + rows from the view; Trino: listed in `SHOW TABLES`, refused with the dialect message |

### Polaris (8)

| Capability | Command | Show this |
|---|---|---|
| Iceberg REST catalog | `cat spark/spark-defaults.conf trino/retail.properties` | Every engine: `uri = http://polaris:8181/api/catalog`, no other catalog, no S3 keys |
| Role-based access | `./run.sh setup` output | `4c`: principal roles → catalog roles; `4d`: `spark_etl -> pipelines`, `trino_bi -> analytics`, … |
| Fine-grained grants | `./run.sh grants`, then `9`, `10` | Grants JSON: namespace `curated`, table `pii.customers`; Trino refused on `pii`; PyIceberg allowed on `pii.customers`, refused on `raw.orders` |
| Credential vending | `./run.sh 14`, and the DELETE in `9` | Temporary key + session token in the allowed response; `403` for pii; Trino's DELETE denied by storage because the keys were read-only |
| OAuth for engines | `./run.sh 14` (first lines), `cat secrets/trino_bi.credential` | A `client_id:secret` per service, exchanged for a bearer token before any catalog call |
| Atomic commits | `./run.sh 16` (and `snapshots` after `7`) | `REJECTED by Polaris: … branch main has changed`, then the retry's snapshot with B's as parent |
| Views in the catalog | `./run.sh 9` | View created in Spark shows up in Trino's `SHOW TABLES FROM curated` |
| Management API and CLI | `./run.sh setup`, `cat polaris-setup.sh` | `POST /api/management/v1/catalogs`, `/catalog-roles`, `/principal-roles`, `/principals`, plain `curl` |

Mentioned on the slides, not demoed: **multiple catalogs** (a second `POST /catalogs` with its own bucket path and IAM role gives an isolated dev catalog).

---

## Part 3: After the session
```bash
./run.sh reset
```
Removes containers, volumes, secrets and generated configs.

---

## If something goes wrong

| Symptom | Likely cause | Fix |
|---|---|---|
| `./run.sh 7` hangs on MERGE for > 60 s | Stream and MERGE racing on a small laptop | Wait; or `./run.sh stop-stream` and retry |
| "Forbidden" or 401 from Spark on a write | Spark started before `setup` wrote its config; or credential refresh turned on | `docker compose restart spark`; keep `client.refresh-credentials-enabled false` in the template |
| Trino "Catalog 'retail' does not exist" | `trino/retail.properties` missing or Trino started too early | `./run.sh setup` then `docker compose restart trino` |
| `./run.sh snapshots` shows nothing new | Stream died (renaming a column it writes kills it: `Field status not found in source schema`) or Step 12 stopped it | `./run.sh status` shows its last log lines; `./run.sh 6` restarts it from its checkpoint |
| Step 11 shows `revenue_before 0.00` | A previous run was interrupted after the UPDATE | `./run.sh sql` then `CALL retail.system.rollback_to_snapshot('curated.daily_sales', <last good id from .snapshots>)` |
| No space left on device | Images are ~13 GB | Free disk, or raise Docker's disk limit |

## What differs from a production deployment
- RustFS instead of S3, with its built-in STS; on AWS, Polaris assumes an IAM role instead and vends keys the same way.
- A Spark streaming job instead of Flink + Kafka, running as `spark_etl` (give it the `flink_stream` credential with `--conf spark.sql.catalog.retail.credential=...` to show the write-only principal).
- One catalog, in-memory metastore: a Polaris restart is a clean slate.
- Spark's Iceberg 1.8.1 calls the credential-refresh endpoint without its bearer token, so refresh is off; vended keys last an hour, long enough for the demo.
- `remove_orphan_files` needs Iceberg 1.9+ or a Hadoop s3a filesystem; it's shown, not executed.
