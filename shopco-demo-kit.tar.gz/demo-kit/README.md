# ShopCo lakehouse: live demo kit

**Start with `DEMO_GUIDE.md`.** It has every step as one `./run.sh` command, the output to expect, what to say, and what to show for each capability. This README is the short reference.

Apache Iceberg + Apache Polaris on one laptop. Five containers, no cloud account.

| Container | Image | Role in the demo | Port |
|---|---|---|---|
| `rustfs` | rustfs/rustfs:1.0.1 | S3-compatible object store with STS (stands in for Amazon S3) | 9000 API, 9001 browser |
| `createbucket` | amazon/aws-cli | Creates the `shopco-lake` bucket, then exits | – |
| `polaris` | apache/polaris:latest | Iceberg REST catalog, RBAC, credential vending | 8181 |
| `spark` | tabulario/spark-iceberg | Spark SQL + streaming writer + PyIceberg | 8888 Jupyter, 8080 UI |
| `trino` | trinodb/trino:latest | BI analyst engine | 8090 |

**Substitutions vs. the production design:** RustFS instead of S3 (it has an STS endpoint, so Polaris vends real, table-scoped temporary keys via `AssumeRole`); a Spark Structured Streaming job instead of Flink + Kafka; one catalog (no `retail_dev`); Polaris in-memory metastore (restart = clean slate).

## Prerequisites
Docker Desktop with **10 GB RAM** and 10 GB disk, `curl`, `jq`. Apple Silicon and x86 both work.

## Replace the kit and set up in one go
With the new `shopco-demo-kit.tar.gz` in the folder above `demo-kit`:
```bash
cd ~/repos/nustudio/polaris-iceberg \
&& { [ -f shopco-demo-kit.tar.gz ] || { echo "download shopco-demo-kit.tar.gz into $(pwd) first"; false; }; } \
&& (cd demo-kit 2>/dev/null && ./run.sh reset; true) \
&& rm -rf demo-kit \
&& tar xzf shopco-demo-kit.tar.gz && rm shopco-demo-kit.tar.gz \
&& cd demo-kit && chmod +x run.sh polaris-setup.sh demo/*.sh \
&& ./run.sh up && ./run.sh setup && ./run.sh engines \
&& ./run.sh 5 && ./run.sh grants && ./run.sh 6 \
&& echo "READY: stream running; give it 2 minutes, then ./run.sh 7"
```

## Before the session (15 min)
```bash
tar xzf shopco-demo-kit.tar.gz && cd demo-kit && chmod +x run.sh polaris-setup.sh demo/*.sh
./run.sh up        # Steps 1-2: storage, bucket, Polaris
./run.sh setup     # Steps 3-4: catalog, roles, principals; writes secrets/ and engine configs
./run.sh engines   # start Spark and Trino
./run.sh 5         # tables
./run.sh grants    # namespace/table grants (tables must exist first)
./run.sh 6         # streaming writer, keep it running
```
Let the stream run at least 2 minutes before the session so there are several snapshots.

Reset everything: `./run.sh reset`.

## Runbook (live part: `./run.sh 7` … `./run.sh 15`)

| # | Capability shown | Run | Point at |
|---|---|---|---|
| 1-2 | Deploy Polaris; bucket | `docker compose ps`; open http://localhost:9001 | Five containers; the empty `shopco-lake` bucket |
| 3 | REST catalog; management API | `./polaris-setup.sh phase1` output (or re-run `curl` from it) | The OAuth token call, then `POST /catalogs` |
| 4 | RBAC; fine-grained grants; CLI/API | same output; `secrets/` folder | Chain principal → principal role → catalog role → grant; one secret per service |
| 5 | Hidden partitioning; table properties | `05_create_tables.sql` | `PARTITIONED BY (day(order_ts))`; merge-on-read props in `DESCRIBE` |
| 6 | ACID commits; multi-engine; OAuth | `06_stream_orders.py` running; `SELECT committed_at, operation FROM retail.raw.orders.snapshots` | A new snapshot every 30 s; the stream uses the `flink_stream`-style principal |
| 7 | Branches, WAP; atomic commits; metadata tables | `07_wap_nightly.sql` while the stream runs | `main` unchanged while `audit` fills; `fast_forward`; `.refs` and `.snapshots` |
| 7b | Incremental reads; tags | `07_incremental_read.py` | Row count between two snapshots; `etl_processed` tag |
| 8 | Schema + partition evolution | `08_evolution.sql` | Same `data_files_before/after`; two `spec_id`s in `.partitions` |
| 9 | Views in catalog; grants enforced; credential vending | `09_view.sql` then `09_trino_queries.sql` | View from Spark readable in Trino; `pii.customers` → Forbidden; `DELETE` → refused |
| 10 | Tags, time travel; table-level grant | `10_tag_training_set.sql`, `10_pyiceberg_notebook.py` | Same row count every run; `pii.customers` allowed, `raw.orders` refused |
| 11 | Rollback | `./run.sh 11` | `revenue_before` = `revenue_restored` |
| 12 | Row-level delete; merge-on-read | `./run.sh 12` (stops the stream) | `files: data / delete 7 / 7`; previous snapshot still has the rows |
| 16 | Two writers, one table: stale commit refused, retry | `./run.sh 16` | `REJECTED by Polaris … branch main has changed`, then committed |
| 13 | Maintenance = the purge | `./run.sh 13` | files 7 data + 7 delete → 2 + 1; snapshots 9 → 2 |
| 14 | Credential vending on the wire | `./run.sh 14` | `s3.*` keys in the allowed response; HTTP 403 for `pii` |
| 15 | The files themselves | `./run.sh 15` or http://localhost:9001 | `metadata/vN.metadata.json`, `snap-*.avro`, Parquet under `data/` |

`./run.sh 12` stops the stream itself. `./run.sh status` and `./run.sh snapshots` show what is going on at any point.

## Tested
Every step prints BEFORE / ACTION / AFTER / WHAT CHANGED. Run end to end on 2026-11-24 with `apache/polaris` 1.9.0, `tabulario/spark-iceberg` (Iceberg 1.8.1), `trinodb/trino:latest`, `rustfs` 1.0.1 (Linux x86, Docker 29, overlay2). Two version-specific points, both already handled in the kit:
- Spark's Iceberg 1.8.1 calls Polaris's credential-refresh endpoint without a bearer token (401), so `client.refresh-credentials-enabled=false` is set; vended keys last an hour.
- `remove_orphan_files` needs Iceberg 1.9+ (`prefix_listing`) or a Hadoop s3a filesystem; Step 13 shows it and moves on.

`apache/polaris:latest` moves; pin the tag that worked for you once you have rehearsed.
