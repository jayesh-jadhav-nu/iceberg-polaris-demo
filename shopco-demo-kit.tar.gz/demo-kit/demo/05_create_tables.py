# Step 5: namespaces and tables (Spark, as spark_etl)
#   ./run.sh 5
from _lib import *
s = spark("shopco-create-tables")

capability("Step 5: create the tables", "hidden partitioning", "table properties (merge-on-read)", "REST catalog: Spark writes through Polaris")

before("namespaces in the catalog")
show(s.sql("SHOW NAMESPACES IN retail"))

action("CREATE NAMESPACE raw, curated, pii; CREATE TABLE raw.orders PARTITIONED BY (day(order_ts)), pii.customers, curated.daily_sales; seed 50 customers")
for ns in ("raw", "curated", "pii"):
    s.sql(f"CREATE NAMESPACE IF NOT EXISTS retail.{ns}")
s.sql("""CREATE TABLE IF NOT EXISTS retail.raw.orders (
  order_id bigint, customer_id bigint, amount decimal(10,2), status string, order_ts timestamp
) USING iceberg
PARTITIONED BY (day(order_ts))
TBLPROPERTIES (
  'format-version' = '2',
  'write.merge.mode'  = 'merge-on-read',
  'write.update.mode' = 'merge-on-read',
  'write.delete.mode' = 'merge-on-read',
  'write.target-file-size-bytes' = '134217728',
  'write.metadata.delete-after-commit.enabled' = 'true',
  'write.metadata.previous-versions-max' = '50')""")
s.sql("CREATE TABLE IF NOT EXISTS retail.pii.customers (customer_id bigint, name string, email string, country string) USING iceberg")
s.sql("""CREATE TABLE IF NOT EXISTS retail.curated.daily_sales (sale_date date, country string, orders bigint, revenue decimal(14,2))
         USING iceberg PARTITIONED BY (sale_date) TBLPROPERTIES ('format-version' = '2')""")
s.sql("""INSERT OVERWRITE retail.pii.customers
         SELECT id, concat('Customer ', id), concat('user', id, '@example.com'),
                element_at(array('DE','FR','GB','US','IN'), cast(id % 5 + 1 AS int)) FROM range(1, 51)""")

after("namespaces and tables")
show(s.sql("SHOW NAMESPACES IN retail"))
for ns in ("raw", "curated", "pii"):
    show(s.sql(f"SHOW TABLES IN retail.{ns}"))
kv("pii.customers rows", one(s, "SELECT count(*) FROM retail.pii.customers"))

print("\n    raw.orders partitioning and write modes (from DESCRIBE TABLE EXTENDED):")
for r in s.sql("DESCRIBE TABLE EXTENDED retail.raw.orders").collect():
    if r.col_name.startswith("Part ") or r.col_name == "Table Properties":
        v = r.data_type
        if r.col_name == "Table Properties":
            v = ", ".join(p for p in v.strip("[]").split(",") if "mode" in p)
        kv(r.col_name, v)

changed("Three namespaces and three tables now exist. raw.orders is split into one partition per day. Queries never mention the partition; Iceberg picks the right files from a filter on order_ts.")
note("Spark wrote the files to s3://shopco-lake/retail/ with keys it got from Polaris. Spark's own config has no S3 keys.")
