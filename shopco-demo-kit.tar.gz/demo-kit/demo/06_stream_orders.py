# Step 6: a streaming writer that commits one Iceberg snapshot every 30 s.
# Stand-in for Flink + Kafka: Spark Structured Streaming with the built-in rate source.
#   docker compose exec -d spark spark-submit /home/iceberg/demo/06_stream_orders.py
# Watch snapshots arrive:  SELECT committed_at, operation, summary['added-records'] FROM retail.raw.orders.snapshots;
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder.appName("shopco-stream-orders").getOrCreate()

orders = (spark.readStream.format("rate").option("rowsPerSecond", 5).load()
    .withColumn("order_id", F.col("value") + 1_000_000)
    .withColumn("customer_id", (F.col("value") % 50) + 1)
    .withColumn("amount", F.round(F.rand() * 300 + 5, 2).cast("decimal(10,2)"))
    .withColumn("status", F.when(F.rand() < 0.9, "PAID").otherwise("CANCELLED"))
    .withColumn("order_ts", F.col("timestamp"))
    .select("order_id", "customer_id", "amount", "status", "order_ts"))

# Write every column the table has right now; columns added after this job started are not in the
# frame, so they are written as NULL. (A rename of a column this job writes would break it: Iceberg
# matches incoming columns by name against the table's current schema.)
table_cols = spark.table("retail.raw.orders").schema
for f in table_cols.fields:
    if f.name not in orders.columns:
        orders = orders.withColumn(f.name, F.lit(None).cast(f.dataType))
orders = orders.select([f.name for f in table_cols.fields])

(orders.writeStream.format("iceberg").outputMode("append")
    .trigger(processingTime="30 seconds")
    .option("checkpointLocation", "/tmp/checkpoints/orders")
    .option("fanout-enabled", "true")
    .toTable("retail.raw.orders")
    .awaitTermination())
