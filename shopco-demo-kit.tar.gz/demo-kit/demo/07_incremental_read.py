# Step 7b: incremental read, only rows appended between two snapshots, bookmarked with a tag.
#   ./run.sh 7b
from _lib import *
s = spark("shopco-incremental")
T = "retail.raw.orders"

capability("Step 7b: read only what is new", "incremental reads", "tags as bookmarks", "metadata tables")

snaps = s.sql(f"SELECT snapshot_id, committed_at FROM {T}.snapshots ORDER BY committed_at").collect()
if len(snaps) < 3:
    print("need at least 3 snapshots; let the stream run a bit longer"); raise SystemExit

before()
tag = {r.name: r.snapshot_id for r in s.sql(f"SELECT name, snapshot_id FROM {T}.refs").collect()}.get("etl_processed")
kv("bookmark tag etl_processed", tag or "none yet")
kv("rows in the whole table", one(s, f"SELECT count(*) FROM {T}"))
kv("snapshots in the table", len(snaps))

start = tag if tag else snaps[-3].snapshot_id
end = snaps[-1].snapshot_id
action(f"read only the rows added after snapshot {start} up to {end}")
new_rows = (s.read.format("iceberg").option("start-snapshot-id", start).option("end-snapshot-id", end).load(T))
kv("rows in that range", new_rows.count())

action("ALTER TABLE ... CREATE OR REPLACE TAG etl_processed AS OF VERSION <end>")
s.sql(f"ALTER TABLE {T} CREATE OR REPLACE TAG etl_processed AS OF VERSION {end}")

after()
show(s.sql(f"SELECT name, type, snapshot_id FROM {T}.refs"))
changed("The job read only the new rows, not the whole table. The tag etl_processed marks where the next run starts.")
