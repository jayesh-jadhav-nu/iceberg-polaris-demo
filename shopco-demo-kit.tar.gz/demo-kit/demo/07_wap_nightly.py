# Step 7: Write-Audit-Publish on a branch (Spark, as spark_etl). Run while the stream is writing.
#   ./run.sh 7
from _lib import *
s = spark("shopco-wap")
T = "retail.curated.daily_sales"
refs = lambda: {r.name: r.snapshot_id for r in s.sql(f"SELECT name, snapshot_id FROM {T}.refs").collect()}
rows_on = lambda ref: one(s, f"SELECT count(*) FROM {T} VERSION AS OF '{ref}'") if ref in refs() else 0
stream_snaps = lambda: (s.sql("REFRESH TABLE retail.raw.orders"), one(s, "SELECT count(*) FROM retail.raw.orders.snapshots"))[1]
import subprocess, time
stream_state = lambda: "RUNNING" if subprocess.run(["pgrep", "-f", "06_stream_orders"], capture_output=True).returncode == 0 else "not running"

capability("Step 7: publish the nightly numbers safely (Write-Audit-Publish)",
           "branches", "ACID snapshots", "row-level MERGE", "metadata tables", "atomic commits with a concurrent writer")

s.sql(f"ALTER TABLE {T} SET TBLPROPERTIES ('write.wap.enabled' = 'true')")
s.sql(f"ALTER TABLE {T} CREATE BRANCH IF NOT EXISTS audit")

before("the nightly job")
r0 = refs(); st0 = stream_snaps()
kv("main: rows / snapshot", f"{rows_on('main')} / {r0.get('main', 'none yet')}")
kv("audit: rows / snapshot", f"{rows_on('audit')} / {r0.get('audit', 'none yet')}")
kv("stream job writing raw.orders", stream_state())
kv("raw.orders snapshots so far", st0)
print("    raw.orders by status (the job counts PAID only):")
show(s.sql("SELECT status, count(*) AS orders, sum(amount) AS amount FROM retail.raw.orders GROUP BY status ORDER BY status"))
paid0 = one(s, "SELECT count(*) FROM retail.raw.orders WHERE status = 'PAID'")

action("SET spark.wap.branch = audit; MERGE INTO curated.daily_sales (daily revenue per country from raw.orders)")
s.sql("SET spark.wap.branch = audit")
s.sql(f"""MERGE INTO {T} t
USING (SELECT date(o.order_ts) AS sale_date, c.country, count(*) AS orders, sum(o.amount) AS revenue
       FROM retail.raw.orders o JOIN retail.pii.customers c USING (customer_id)
       WHERE o.status = 'PAID' GROUP BY 1, 2) src
ON t.sale_date = src.sale_date AND t.country = src.country
WHEN MATCHED THEN UPDATE SET * WHEN NOT MATCHED THEN INSERT *""")

after("the MERGE, before publishing")
r1 = refs()
kv("main: rows / snapshot", f"{rows_on('main')} / {r1.get('main', 'none yet')}")
kv("audit: rows / snapshot", f"{rows_on('audit')} / {r1.get('audit')}")
kv("orders counted on the branch", f"{one(s, f'SELECT sum(orders) FROM {T} VERSION AS OF ' + chr(39) + 'audit' + chr(39))}  (PAID orders at merge time: about {paid0}; CANCELLED ones excluded)")
if r1.get("main") == r0.get("main"):
    same("main did not change. Anyone reading main still sees the old numbers.")
changed("The new numbers exist only on the audit branch.")

if stream_state() == "RUNNING":
    note("waiting for the stream's next batch, to show another writer landing while our results sit on the branch ...")
    for _ in range(8):
        if stream_snaps() > st0: break
        time.sleep(5)
    st_mid = stream_snaps()
    kv("stream job", stream_state())
    kv("raw.orders snapshots now", f"{st_mid}  (+{st_mid - st0} committed by the stream since we started)")
    if st_mid > st0:
        changed("The stream wrote a new batch to raw.orders while our results sat on the branch. Neither one had to wait for the other.")

action("AUDIT the branch: three checks")
neg  = one(s, f"SELECT count(*) FROM {T} VERSION AS OF 'audit' WHERE revenue < 0")
nul  = one(s, f"SELECT count(*) FROM {T} VERSION AS OF 'audit' WHERE sale_date IS NULL")
kv("rows with negative revenue", neg)
kv("rows with null sale_date", nul)
show(s.sql(f"SELECT sale_date, country, orders, revenue FROM {T} VERSION AS OF 'audit' ORDER BY 1, 2"))
ok = neg == 0 and nul == 0
kv("checks passed", ok)

if ok:
    action("PUBLISH: CALL fast_forward('main', 'audit')  (moves main's pointer, no data copied)")
    s.sql("RESET spark.wap.branch")
    show(s.sql(f"CALL retail.system.fast_forward('curated.daily_sales', 'main', 'audit')"))
    after("publish")
    r2 = refs()
    kv("main: rows / snapshot", f"{rows_on('main')} / {r2.get('main')}")
    kv("audit: rows / snapshot", f"{rows_on('audit')} / {r2.get('audit')}")
    changed("main now has the checked numbers. Spark, Trino and PyIceberg all see them from now on.")
else:
    changed("A check failed. Nothing was published and main is unchanged.")

st1 = stream_snaps()
kv("stream job", stream_state())
kv("raw.orders snapshots at the end", f"{st1}  (+{st1 - st0} committed by the stream during this job, no conflict)")
print("\n    snapshot history of daily_sales:")
show(s.sql(f"SELECT committed_at, operation, summary['added-records'] AS added FROM {T}.snapshots ORDER BY committed_at"))
