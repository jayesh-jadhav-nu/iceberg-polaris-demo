# Step 8: schema and partition evolution, no data rewritten (Spark, as spark_etl). Safe to rerun.
#   ./run.sh 8
from _lib import *
s = spark("shopco-evolution")
T = "retail.raw.orders"
cols = lambda: [(r.col_name, r.data_type) for r in s.sql(f"DESCRIBE TABLE {T}").collect() if r.col_name and not r.col_name.startswith(("#", "Part ")) and r.data_type]
parts = lambda: [r.data_type for r in s.sql(f"DESCRIBE TABLE {T}").collect() if r.col_name.startswith("Part ")]
files = lambda: one(s, f"SELECT count(*) FROM {T}.files WHERE content = 0")

capability("Step 8: change a live table without rewriting it", "schema evolution", "partition evolution", "hidden partitioning")

import os, json, subprocess, time
cred = os.environ.get("SPARK_CRED")
tbl0 = None
if cred:
    from pyiceberg.catalog import load_catalog
    import pyarrow as pa, pyarrow.parquet as pq
    cat = load_catalog("retail", type="rest", uri="http://polaris:8181/api/catalog", warehouse="retail",
        credential=cred, scope="PRINCIPAL_ROLE:ALL",
        **{"header.X-Iceberg-Access-Delegation": "vended-credentials", "s3.endpoint": "http://rustfs:9000",
           "s3.path-style-access": "true", "s3.region": "us-east-1"})
    tbl0 = cat.load_table("raw.orders")

before()
c0 = dict(cols()); p0 = parts(); f0 = files()
if tbl0: kv("current metadata.json", tbl0.metadata_location.split("/")[-1])
kv("columns", ", ".join(f"{k} {v}" for k, v in c0.items()))
kv("partitioned by", ", ".join(p0))
kv("data files", f0)

did = []
if "coupon_code" not in c0 and "promo_code" not in c0:
    s.sql(f"ALTER TABLE {T} ADD COLUMN coupon_code string");           did.append("ADD COLUMN coupon_code string")
if c0.get("amount") != "decimal(12,2)":
    s.sql(f"ALTER TABLE {T} ALTER COLUMN amount TYPE decimal(12,2)"); did.append("ALTER COLUMN amount TYPE decimal(12,2)")
if "promo_code" not in c0:
    s.sql(f"ALTER TABLE {T} RENAME COLUMN coupon_code TO promo_code"); did.append("RENAME COLUMN coupon_code TO promo_code")
if not any("hours(" in p for p in p0):
    s.sql(f"ALTER TABLE {T} REPLACE PARTITION FIELD order_ts_day WITH hour(order_ts)"); did.append("REPLACE PARTITION FIELD day(order_ts) WITH hour(order_ts)")
action("; ".join(did) if did else "nothing to do, already evolved (rerun)")

after()
c1 = dict(cols()); p1 = parts(); f1 = files()
kv("columns", ", ".join(f"{k} {v}" for k, v in c1.items()))
kv("partitioned by", ", ".join(p1))
kv("data files", f"{f1}  (before: {f0}; any difference is the stream committing meanwhile)")
print("\n    old rows read with the new schema:")
show(s.sql(f"SELECT order_id, status, amount, promo_code FROM {T} LIMIT 5"))
print("    partition specs in use (0 = daily files, 1 = hourly files; spec 1 fills as the stream writes):")
show(s.sql(f"SELECT spec_id, partition, record_count FROM {T}.partitions ORDER BY spec_id, partition"))

changed(f"The table has {len(c1)} columns instead of {len(c0)}: coupon_code was added and then renamed to promo_code, amount was widened. New data is split by hour instead of by day.")
same("No data file was rewritten. Old rows show NULL for promo_code and stay in their daily folders.")
note("(a column a running writer still writes, like status, is not renamed here: the writer would fail on its next batch)")

print("\n--- WHERE THE CHANGE LIVES, PHYSICALLY ---------------------------------")
# 1. column ids recorded in each data file's footer (via the manifests): old files have ids 1-5, new ones 1-6
print("    column ids inside each data file (from the Parquet footers; promo_code is id 6):")
show(s.sql(f"SELECT regexp_extract(file_path, '[^/]+$', 0) AS file, spec_id, map_keys(column_sizes) AS column_ids FROM {T}.files WHERE content = 0 ORDER BY spec_id, file"))

# 2. the metadata.json files and the Parquet files themselves, read through Polaris-vended credentials (PyIceberg FileIO)
if cred:
    tbl = cat.load_table("raw.orders")
    read_bytes = lambda path: tbl.io.new_input(path).open().read()
    if tbl.metadata_location != tbl0.metadata_location:
        prev = json.loads(read_bytes(tbl0.metadata_location))
        prev_schema = [x for x in prev["schemas"] if x["schema-id"] == prev["current-schema-id"]][0]
        kv("metadata.json BEFORE this step", tbl0.metadata_location.split("/")[-1])
        kv("  its schema", ", ".join(f["name"] for f in prev_schema["fields"]) + f"   (default spec {prev['default-spec-id']})")
        kv("metadata.json AFTER this step", tbl.metadata_location.split("/")[-1])
        kv("  its schema", ", ".join(f.name for f in tbl.schema().fields) + f"   (default spec {tbl.metadata.default_spec_id})")
        note("Each ALTER wrote a new metadata.json. That is the whole change.")
    else:
        kv("metadata.json", tbl.metadata_location.split("/")[-1] + "   (unchanged: nothing to evolve on this rerun)")
    if subprocess.run(["pgrep", "-f", "06_stream_orders"], capture_output=True).returncode == 0 \
            and one(s, f"SELECT count(*) FROM {T}.files WHERE content = 0 AND spec_id = 1") == 0:
        note("The running stream still writes with the schema it started with (a Flink job would too).")
        note("Restarting it so its next batch uses the new schema, then waiting for that batch (about 60 s) ...")
        subprocess.run(["pkill", "-f", "06_stream_orders"])
        time.sleep(2)
        subprocess.Popen(["setsid", "sh", "-c", "nohup spark-submit /home/iceberg/demo/06_stream_orders.py > /tmp/stream.log 2>&1 &"])
        for _ in range(24):
            s.sql(f"REFRESH TABLE {T}")
            if one(s, f"SELECT count(*) FROM {T}.files WHERE content = 0 AND spec_id = 1") > 0: break
            time.sleep(5)
    files_df = s.sql(f"SELECT file_path, spec_id FROM {T}.files WHERE content = 0 ORDER BY spec_id, file_path").collect()
    old_f = next((r.file_path for r in files_df if r.spec_id == 0), None)
    new_f = next((r.file_path for r in reversed(files_df) if r.spec_id == 1), None)
    for label, fpath in (("an old data file", old_f), ("a new data file", new_f)):
        if fpath:
            schema = pq.read_schema(pa.BufferReader(read_bytes(fpath)))
            kv(label, fpath.split("/data/")[-1])
            kv("  columns inside the Parquet file", ", ".join(schema.names))
        elif label.startswith("a new"):
            kv("a new data file", "none yet. The stream's next batch will use the new schema; check later with ./run.sh files")
    note("Old files still have their original 5 columns. Iceberg matches columns by id, so it reads them fine and fills promo_code with NULL.")
else:
    note("(set SPARK_CRED to also print the metadata.json schemas and the Parquet file schemas)")

