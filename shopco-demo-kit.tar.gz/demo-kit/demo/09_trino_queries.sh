#!/usr/bin/env bash
# Step 9b: the BI analyst in Trino, as trino_bi (analytics -> reader: read on curated only).
#   ./run.sh 9
cd "$(dirname "$0")/.."
run() { # run EXPECTATION "sql"
  local expect=$1 sql=$2
  printf '\n>>> %s\n    expect: %s\n' "$sql" "$expect"
  local out; out=$(docker compose exec -T trino trino --catalog retail --output-format CSV_HEADER --execute "$sql" 2>&1)
  if echo "$out" | grep -q "^Query .* failed"; then
    printf '    RESULT: REFUSED -> %s\n' "$(echo "$out" | grep -o 'failed:.*' | cut -c9-120)"
  else
    printf '    RESULT: OK\n'; echo "$out" | sed 's/^/      /'
  fi
  echo
}
echo "=============================================================================="
echo "  Step 9b: query as the analyst (Trino, logged in as trino_bi)"
echo "  demonstrates: fine-grained grants · credential vending · views listed across engines"
echo "=============================================================================="
echo; echo "--- BEFORE: what trino_bi may do ---------------------------------------------"
echo "    role chain: trino_bi -> analytics -> reader; grants: TABLE_READ_DATA on namespace curated, nothing on raw or pii"
echo "    S3 keys in trino/retail.properties: $(grep -cE '^s3\.aws-(access|secret)-key' trino/retail.properties)  (it has the Polaris URL and an OAuth client id/secret, nothing for S3)"

run "OK: reader may read curated; Polaris vends read-only keys for it" \
    "SELECT country, sum(revenue) AS revenue FROM curated.daily_sales GROUP BY country ORDER BY revenue DESC"
run "OK: namespace names may be listed (NAMESPACE_LIST)" "SHOW SCHEMAS"
run "OK: lists the table and the view Spark created" "SHOW TABLES FROM curated"
run "REFUSED by Trino: the view only has a Spark-dialect SQL representation" \
    "SELECT * FROM curated.weekly_sales"
run "REFUSED by Polaris: no grant on pii -> 403, no credentials vended" \
    "SELECT email FROM pii.customers"
run "REFUSED by storage: Polaris vended read-only keys, so the Parquet write gets AccessDenied" \
    "DELETE FROM curated.daily_sales WHERE country = 'DE'"

echo; echo "*** WHAT THIS SHOWS: one identity, three outcomes. curated data came back. pii was refused by Polaris"
echo "    before any key was handed out. The DELETE was refused by storage, because the keys Polaris handed out were read-only."
