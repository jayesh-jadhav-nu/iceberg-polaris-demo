# Step 9a: a view stored in Polaris (Spark, as spark_etl)
#   ./run.sh 9
from _lib import *
s = spark("shopco-view")

capability("Step 9a: a view stored in the catalog", "Iceberg views", "multi-engine access")

before()
show(s.sql("SHOW VIEWS IN retail.curated"))

action("CREATE OR REPLACE VIEW curated.weekly_sales AS weekly revenue per country")
s.sql("""CREATE OR REPLACE VIEW retail.curated.weekly_sales AS
         SELECT date_trunc('week', sale_date) AS week, country, sum(orders) AS orders, sum(revenue) AS revenue
         FROM retail.curated.daily_sales GROUP BY 1, 2""")

after()
show(s.sql("SHOW VIEWS IN retail.curated"))
show(s.sql("SELECT * FROM retail.curated.weekly_sales ORDER BY week DESC, country"))
changed("The view is stored in Polaris, so every engine can see it. Trino will list it next. Its SQL is stored in Spark's dialect, so only Spark can run it.")
