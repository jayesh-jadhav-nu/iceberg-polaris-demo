# Step 10b: data scientist reads the tagged snapshot with PyIceberg (principal ds_notebook)
#   ./run.sh 10
import os
from pyiceberg.catalog import load_catalog

print("\n" + "=" * 78)
print("  Step 10b: read the pinned data from plain Python (PyIceberg, logged in as ds_notebook)")
print("  demonstrates: time travel by tag · a third engine · table-level grant")
print("=" * 78)

cat = load_catalog("retail", type="rest", uri="http://polaris:8181/api/catalog", warehouse="retail",
    credential=os.environ["DS_CRED"], scope="PRINCIPAL_ROLE:ALL",
    **{"header.X-Iceberg-Access-Delegation": "vended-credentials",
       "s3.endpoint": "http://rustfs:9000", "s3.path-style-access": "true", "s3.region": "us-east-1"})

print("\n--- BEFORE: what ds_notebook may do ------------------------------------------")
print("    role chain: ds_notebook -> data_science -> reader (curated) + ds_extra (table pii.customers only)")

print("\n>>> ACTION: load curated.daily_sales at tag model_v3_training")
sales = cat.load_table("curated.daily_sales")
snap = sales.snapshot_by_name("model_v3_training")
train = sales.scan(snapshot_id=snap.snapshot_id).to_pandas()
print(f"    RESULT: OK, training rows (pinned to tag model_v3_training): {len(train)}  snapshot {snap.snapshot_id}")
print(train.head().to_string().replace("\n", "\n      "))

print("\n>>> ACTION: load pii.customers  (expect: OK, the one PII table granted at table level)")
customers = cat.load_table("pii.customers").scan().to_pandas()
print(f"    RESULT: OK, customers: {len(customers)}")

print("\n>>> ACTION: load raw.orders  (expect: REFUSED, no grant on raw)")
try:
    cat.load_table("raw.orders"); print("    RESULT: unexpectedly allowed")
except Exception as e:
    print(f"    RESULT: REFUSED -> {type(e).__name__}: {str(e)[:110]}")

print("\n*** WHAT THIS SHOWS: plain Python, no Spark. It read the rows the model trained on, read the one PII table")
print("    it was granted, and was refused everything else. Run this again in a year and you get the same training rows.")
