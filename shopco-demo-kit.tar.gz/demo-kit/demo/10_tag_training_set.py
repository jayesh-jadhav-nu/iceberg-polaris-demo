# Step 10a: tag the snapshot a model trains on (Spark, as spark_etl)
#   ./run.sh 10
from _lib import *
s = spark("shopco-tag")
T = "retail.curated.daily_sales"

capability("Step 10a: pin the training data", "tags", "time travel")

before()
show(s.sql(f"SELECT name, type, snapshot_id, max_reference_age_in_ms AS retention_ms FROM {T}.refs"))

action("ALTER TABLE curated.daily_sales CREATE OR REPLACE TAG model_v3_training RETAIN 365 DAYS")
s.sql(f"ALTER TABLE {T} CREATE OR REPLACE TAG `model_v3_training` RETAIN 365 DAYS")

after()
show(s.sql(f"SELECT name, type, snapshot_id, max_reference_age_in_ms AS retention_ms FROM {T}.refs"))
kv("rows at the tag (VERSION AS OF 'model_v3_training')", one(s, f"SELECT count(*) FROM {T} VERSION AS OF 'model_v3_training'"))
changed("The tag model_v3_training points at today's snapshot and is kept for 365 days. Reading the table by that tag always gives these same 5 rows, even after the table changes. main moves on; the tag stays put.")
note("Next: PyIceberg reads it as ds_notebook.")
