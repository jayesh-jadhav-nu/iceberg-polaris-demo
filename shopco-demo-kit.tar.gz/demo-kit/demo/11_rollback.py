# Step 11: break it, then roll back (Spark, as spark_etl)
#   ./run.sh 11
from _lib import *
s = spark("shopco-rollback")
T = "retail.curated.daily_sales"

capability("Step 11: undo a bad job", "time travel and rollback", "metadata tables", "atomic pointer swap")

before()
rev0 = one(s, f"SELECT sum(revenue) FROM {T}")
good = one(s, f"SELECT snapshot_id FROM {T}.refs WHERE name = 'main'")
kv("revenue_before", rev0)
kv("main snapshot", good)

action("the 2 a.m. bug:  UPDATE curated.daily_sales SET revenue = 0")
s.sql(f"UPDATE {T} SET revenue = 0")
after("the bug")
kv("revenue_after_bug", one(s, f"SELECT sum(revenue) FROM {T}"))
kv("main snapshot", one(s, f"SELECT snapshot_id FROM {T}.refs WHERE name = 'main'"))
print("    snapshot history (newest first):")
show(s.sql(f"SELECT snapshot_id, committed_at, operation FROM {T}.snapshots ORDER BY committed_at DESC LIMIT 3"))

action(f"CALL rollback_to_snapshot('curated.daily_sales', {good})   (the last good one)")
show(s.sql(f"CALL retail.system.rollback_to_snapshot('curated.daily_sales', {good})"))
after("rollback")
rev2 = one(s, f"SELECT sum(revenue) FROM {T}")
kv("revenue_restored", rev2)
kv("main snapshot", one(s, f"SELECT snapshot_id FROM {T}.refs WHERE name = 'main'"))
changed(f"main points at the good snapshot again. Revenue went {rev0} -> 0 -> {rev2}. No data was copied. The bad snapshot stays in the history until it expires.")
