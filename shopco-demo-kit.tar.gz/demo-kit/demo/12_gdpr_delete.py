# Step 12: GDPR delete (Spark, as spark_etl). The physical purge is the maintenance job in Step 13.
#   ./run.sh 12
from _lib import *
s = spark("shopco-gdpr")
T = "retail.raw.orders"
files_by_content = lambda: {r.content: r.files for r in s.sql(f"SELECT content, count(*) AS files FROM {T}.files GROUP BY content").collect()}

capability("Step 12: forget a customer (the logical delete)", "row-level DELETE", "merge-on-read", "time travel")

cid = one(s, f"SELECT coalesce(max(CASE WHEN customer_id = 42 THEN 42 END), max(customer_id)) FROM {T}")
before()
n0 = one(s, f"SELECT count(*) FROM {T} WHERE customer_id = {cid}")
f0 = files_by_content()
kv("customer to forget", cid)
kv("their rows in raw.orders", n0)
kv("files: data / delete", f"{f0.get(0, 0)} / {f0.get(1, 0)}")

action(f"DELETE FROM pii.customers WHERE customer_id = {cid};  DELETE FROM raw.orders WHERE customer_id = {cid}")
s.sql(f"DELETE FROM retail.pii.customers WHERE customer_id = {cid}")
s.sql(f"DELETE FROM {T} WHERE customer_id = {cid}")

after()
f1 = files_by_content()
prev = one(s, f"SELECT snapshot_id FROM {T}.snapshots ORDER BY committed_at DESC LIMIT 1 OFFSET 1")
kv("their rows in raw.orders", one(s, f"SELECT count(*) FROM {T} WHERE customer_id = {cid}"))
kv("files: data / delete", f"{f1.get(0, 0)} / {f1.get(1, 0)}")
kv(f"their rows in the previous snapshot", one(s, f"SELECT count(*) FROM {T} VERSION AS OF {prev} WHERE customer_id = {cid}"))
changed(f"Queries now return 0 rows for customer {cid}. But the DELETE only added {f1.get(1,0) - f0.get(1,0)} small delete files. The data files are untouched, and the previous snapshot still returns all {n0} rows.")
note("The rows are hidden, not gone. Step 13 compacts the files and expires old snapshots. That is the real purge.")
