# Step 13: maintenance, which is also the physical purge for Step 12 (Spark, as spark_etl)
#   ./run.sh 13
from _lib import *
s = spark("shopco-maintenance")
T = "retail.raw.orders"
stats = lambda: {r.content: (r.files, r.avg_kb) for r in s.sql(f"SELECT content, count(*) AS files, round(avg(file_size_in_bytes)/1024, 1) AS avg_kb FROM {T}.files GROUP BY content").collect()}
snaps = lambda: one(s, f"SELECT count(*) FROM {T}.snapshots")

capability("Step 13: maintenance = the physical purge", "compaction", "manifest rewrite", "snapshot expiry", "orphan cleanup")

before()
st0 = stats(); sn0 = snaps()
kv("data files / avg KB", f"{st0.get(0, (0, 0))[0]} / {st0.get(0, (0, 0))[1]}")
kv("delete files", st0.get(1, (0, 0))[0])
kv("snapshots", sn0)
kv("refs", ", ".join(f"{r.name} ({r.type})" for r in s.sql(f"SELECT name, type FROM {T}.refs").collect()))

action("CALL rewrite_data_files(raw.orders, rewrite-all)   merge small files, apply the delete files")
show(s.sql("CALL retail.system.rewrite_data_files(table => 'raw.orders', options => map('rewrite-all', 'true'))"))
action("CALL rewrite_position_delete_files(raw.orders)   drop delete files that no longer apply")
show(s.sql("CALL retail.system.rewrite_position_delete_files(table => 'raw.orders')"))
action("CALL rewrite_manifests(raw.orders)")
show(s.sql("CALL retail.system.rewrite_manifests('raw.orders')"))
now = one(s, "SELECT date_format(current_timestamp(), 'yyyy-MM-dd HH:mm:ss')")
action("CALL expire_snapshots(raw.orders and pii.customers, retain_last => 1)   drop the files only old snapshots reference")
show(s.sql(f"CALL retail.system.expire_snapshots(table => 'raw.orders', older_than => TIMESTAMP '{now}', retain_last => 1)"))
show(s.sql(f"CALL retail.system.expire_snapshots(table => 'pii.customers', older_than => TIMESTAMP '{now}', retain_last => 1)"))
action("CALL remove_orphan_files(raw.orders)   leftovers from failed writes")
try:
    show(s.sql("CALL retail.system.remove_orphan_files(table => 'raw.orders', prefix_listing => true)"))
except Exception as e:
    note("skipped on this image: " + str(e).split("\n")[0][:80])
    note("(needs Iceberg 1.9+ for prefix_listing, or a Hadoop s3a FileSystem; it runs weekly in the maintenance job)")

after()
st1 = stats(); sn1 = snaps()
kv("data files / avg KB", f"{st1.get(0, (0, 0))[0]} / {st1.get(0, (0, 0))[1]}")
kv("delete files", st1.get(1, (0, 0))[0])
kv("snapshots", sn1)
refs = [(r.name, r.type) for r in s.sql(f"SELECT name, type FROM {T}.refs").collect()]
kv("refs", ", ".join(f"{n} ({t})" for n, t in refs))
changed(f"Files: {st0.get(0,(0,0))[0]} data + {st0.get(1,(0,0))[0]} delete -> {st1.get(0,(0,0))[0]} data + {st1.get(1,(0,0))[0]} delete. Snapshots: {sn0} -> {sn1}. The deleted customer's rows are no longer in any file the table can reach.")
if any(t == "TAG" for _, t in refs):
    note("The tag above keeps its snapshot alive. To finish a purge, drop old tags too.")
