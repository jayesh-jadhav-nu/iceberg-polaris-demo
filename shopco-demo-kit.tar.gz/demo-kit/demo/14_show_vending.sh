#!/usr/bin/env bash
# Step 14: credential vending, seen on the wire.
# Loads a table as trino_bi with X-Iceberg-Access-Delegation and prints the storage config Polaris returns.
# Then tries pii.customers with the same principal and shows the refusal.
set -euo pipefail
cd "$(dirname "$0")/.."
POLARIS=${POLARIS:-http://localhost:8181}
CRED=$(cat secrets/trino_bi.credential); ID=${CRED%%:*}; SECRET=${CRED#*:}

TOKEN=$(curl -sS -X POST "$POLARIS/api/catalog/v1/oauth/tokens" -H 'Polaris-Realm: POLARIS' \
  -d grant_type=client_credentials -d client_id="$ID" -d client_secret="$SECRET" -d scope=PRINCIPAL_ROLE:ALL | jq -r .access_token)

echo "== loadTable curated.daily_sales as trino_bi (allowed): storage keys come back in config"
curl -sS "$POLARIS/api/catalog/v1/retail/namespaces/curated/tables/daily_sales" \
  -H "Authorization: Bearer $TOKEN" -H 'Polaris-Realm: POLARIS' \
  -H 'X-Iceberg-Access-Delegation: vended-credentials' \
  | jq '{metadataLocation: .["metadata-location"], config: (.config | with_entries(select(.key | startswith("s3."))) | map_values(.[0:6] + "…"))}'

echo
echo "== loadTable pii.customers as trino_bi (refused): no credentials, no metadata"
curl -sS -o /dev/stderr -w 'HTTP %{http_code}\n' "$POLARIS/api/catalog/v1/retail/namespaces/pii/tables/customers" \
  -H "Authorization: Bearer $TOKEN" -H 'Polaris-Realm: POLARIS' -H 'X-Iceberg-Access-Delegation: vended-credentials'
