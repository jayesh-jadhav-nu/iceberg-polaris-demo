#!/usr/bin/env bash
# Step 15: look at the files Iceberg wrote (same idea as the Dremio laptop lab).
# Or open http://localhost:9001 (admin / password) and browse shopco-lake/retail/.
set -euo pipefail
docker run --rm --network "$(basename "$(cd "$(dirname "$0")/.." && pwd)")_shopco" \
  -e AWS_ACCESS_KEY_ID=admin -e AWS_SECRET_ACCESS_KEY=password -e AWS_DEFAULT_REGION=us-east-1 \
  --entrypoint /bin/sh amazon/aws-cli:2.37.12 -c \
  "aws configure set default.s3.addressing_style path && \
   aws --endpoint-url http://rustfs:9000 s3 ls --recursive s3://shopco-lake/retail/curated/daily_sales/ | sed 's/^/  /'"
echo
echo "metadata/  -> vN.metadata.json (one per commit), snap-*.avro (manifest lists), *-m0.avro (manifests)"
echo "data/      -> Parquet files under partition folders; never edited in place"
