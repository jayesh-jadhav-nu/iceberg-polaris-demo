# Step 16: two writers commit to the SAME table; the catalog rejects the stale one, which retries.
#   ./run.sh 16
# Writer A is PyIceberg (plain Python), writer B is Spark. Both act as spark_etl. Deterministic: no timing games.
import os
from _lib import *
from datetime import datetime, timezone
import pyarrow as pa
from pyiceberg.catalog import load_catalog
from pyiceberg.exceptions import CommitFailedException

s = spark("shopco-concurrent")
T = "retail.raw.orders"
cat = load_catalog("retail", type="rest", uri="http://polaris:8181/api/catalog", warehouse="retail",
    credential=os.environ["SPARK_CRED"], scope="PRINCIPAL_ROLE:ALL",
    **{"header.X-Iceberg-Access-Delegation": "vended-credentials", "s3.endpoint": "http://rustfs:9000",
       "s3.path-style-access": "true", "s3.region": "us-east-1"})

capability("Step 16: two writers, one table", "optimistic concurrency", "atomic commits in the catalog", "automatic retry")

def rows_for(tbl, n, start_id):
    sch = tbl.schema().as_arrow()
    now = datetime.now(timezone.utc)
    recs = [{"order_id": start_id + i, "customer_id": 1 + i % 50, "amount": None, "status": "PAID", "order_ts": now} for i in range(n)]
    for r in recs:
        for f in sch:
            if f.name not in r: r[f.name] = None
    return pa.Table.from_pylist(recs, schema=sch)

before()
tbl = cat.load_table("raw.orders")
n0 = tbl.current_snapshot().snapshot_id if tbl.current_snapshot() else None
kv("current snapshot (both writers read this)", n0)
kv("rows", one(s, f"SELECT count(*) FROM {T}"))

action("Writer A (PyIceberg) prepares an append of 10 rows against that snapshot, but does not commit yet")
txn = tbl.transaction()
txn.append(rows_for(tbl, 10, 9_000_000))
note("its data file is written to the bucket; nothing in the catalog has changed")

action("Writer B (Spark) commits an INSERT of 5 rows to the same table first")
s.sql(f"INSERT INTO {T} (order_id, customer_id, amount, status, order_ts) VALUES " +
      ", ".join(f"({8_000_000 + i}, {i + 1}, 10.00, 'PAID', current_timestamp())" for i in range(5)))
n1 = one(s, f"SELECT snapshot_id FROM {T}.refs WHERE name = 'main'")
kv("table snapshot now", f"{n1}  (moved by writer B)")

action("Writer A now tries to commit its append, still based on the old snapshot")
try:
    txn.commit_transaction()
    kv("result", "committed without conflict (the library detected the move and merged)")
except CommitFailedException as e:
    kv("result", "REJECTED by Polaris: " + str(e).splitlines()[0][:110])
    note("the catalog compared writer A's expected snapshot with the current one and refused the pointer swap")
    action("Writer A reloads the table and commits the same append on top of writer B's snapshot (the retry)")
    tbl = cat.load_table("raw.orders")
    tbl.append(rows_for(tbl, 10, 9_000_000))
    kv("result", "committed")

after()
s.sql(f"REFRESH TABLE {T}")   # Spark caches table metadata; pick up the commit PyIceberg just made
n2 = one(s, f"SELECT snapshot_id FROM {T}.refs WHERE name = 'main'")
kv("table snapshot now", f"{n2}  (moved again, by writer A's retry)")
kv("rows", f"{one(s, f'SELECT count(*) FROM {T}')}  (+5 from B, +10 from A)")
print("    the last three snapshots, newest first (parent_id shows the chain):")
show(s.sql(f"SELECT snapshot_id, parent_id, operation, summary['added-records'] AS added FROM {T}.snapshots ORDER BY committed_at DESC LIMIT 3"))
changed("Both writers' rows are in the table. Writer B's commit landed first; writer A's first attempt was refused because the table had moved, and its retry committed on top of B. No lock, no lost update, no corruption.")
