# Shared helpers so every demo step prints the same way:
#   CAPABILITY banner, BEFORE state, the ACTION, AFTER state, and a one-line WHAT CHANGED verdict.
from pyspark.sql import SparkSession

def spark(name):
    return SparkSession.builder.appName(name).getOrCreate()

def capability(title, *caps):
    print("\n" + "=" * 78)
    print(f"  {title}")
    print("  demonstrates: " + " · ".join(caps))
    print("=" * 78)
    print()

def before(label=""):  print(f"\n--- BEFORE {label}".rstrip() + " " + "-" * max(0, 60 - len(label)) + "\n")
def action(text):      print(f"\n>>> ACTION: {text}\n")
def after(label=""):   print(f"\n--- AFTER {label}".rstrip() + " " + "-" * max(0, 61 - len(label)) + "\n")
def changed(text):     print(f"\n*** WHAT CHANGED: {text}\n")
def same(text):        print(f"\n*** UNCHANGED: {text}\n")
def note(text):        print(f"    {text}")

def kv(label, value):  print(f"    {label:<34} {value}")

def show(df, n=20):
    for line in df._jdf.showString(n, 60, False).splitlines():
        print("    " + line)

def one(s, sql):
    return s.sql(sql).collect()[0][0]
