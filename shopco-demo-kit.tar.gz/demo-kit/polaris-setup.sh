#!/usr/bin/env bash
# Polaris setup for the ShopCo demo, against the management REST API.
#   ./polaris-setup.sh phase1   # catalog, catalog roles, catalog-level grants, principal roles, principals
#   ./polaris-setup.sh phase2   # namespace- and table-level grants (run AFTER 05_create_tables.sql)
# Needs: curl, jq. Writes principal secrets to ./secrets/ and fills the engine config templates.
set -euo pipefail
cd "$(dirname "$0")"

POLARIS=${POLARIS:-http://localhost:8181}
ROOT_ID=root; ROOT_SECRET=s3cr3t
CATALOG=retail
BUCKET_PATH=s3://shopco-lake/retail

say()  { printf '\n\033[1;36m== %s\033[0m\n' "$*"; }
api()  { # api METHOD PATH [JSON]
  local m=$1 p=$2 d=${3:-}
  if [ -n "$d" ]; then
    curl -sS -X "$m" "$POLARIS/api/management/v1$p" -H "Authorization: Bearer $TOKEN" \
         -H 'Content-Type: application/json' -H 'Polaris-Realm: POLARIS' -d "$d"
  else
    curl -sS -X "$m" "$POLARIS/api/management/v1$p" -H "Authorization: Bearer $TOKEN" -H 'Polaris-Realm: POLARIS'
  fi
  echo
}

say "Get an admin token (OAuth client credentials)"
TOKEN=$(curl -sS -X POST "$POLARIS/api/catalog/v1/oauth/tokens" -H 'Polaris-Realm: POLARIS' \
  -d grant_type=client_credentials -d client_id=$ROOT_ID -d client_secret=$ROOT_SECRET \
  -d scope=PRINCIPAL_ROLE:ALL | jq -r .access_token)
[ "$TOKEN" != "null" ] || { echo "no token; is Polaris up on $POLARIS ?"; exit 1; }

phase1() {
  say "Step 3: create the catalog '$CATALOG' at $BUCKET_PATH"
  api POST /catalogs "$(cat <<EOF
{"catalog":{"name":"$CATALOG","type":"INTERNAL","readOnly":false,
  "properties":{"default-base-location":"$BUCKET_PATH"},
  "storageConfigInfo":{"storageType":"S3",
    "roleArn":"arn:aws:iam::000000000000:role/polaris-demo",
    "allowedLocations":["$BUCKET_PATH"],
    "endpoint":"http://rustfs:9000","stsEndpoint":"http://rustfs:9000","pathStyleAccess":true}}}
EOF
)"

  say "Step 4a: catalog roles"
  for r in engineer catalog_reader stream_writer reader ds_extra; do
    api POST /catalogs/$CATALOG/catalog-roles "{\"catalogRole\":{\"name\":\"$r\"}}"
  done

  say "Step 4b: catalog-level grants"
  api PUT /catalogs/$CATALOG/catalog-roles/engineer/grants       '{"grant":{"type":"catalog","privilege":"CATALOG_MANAGE_CONTENT"}}'
  for p in TABLE_READ_DATA TABLE_LIST NAMESPACE_LIST VIEW_LIST; do
    api PUT /catalogs/$CATALOG/catalog-roles/catalog_reader/grants "{\"grant\":{\"type\":\"catalog\",\"privilege\":\"$p\"}}"
  done

  say "Step 4c: principal roles and which catalog roles they hold"
  for pr in pipelines data_eng streaming analytics data_science; do
    api POST /principal-roles "{\"principalRole\":{\"name\":\"$pr\"}}"
  done
  grant_cr() { api PUT /principal-roles/$1/catalog-roles/$CATALOG "{\"catalogRole\":{\"name\":\"$2\"}}"; }
  grant_cr pipelines    engineer
  grant_cr data_eng     catalog_reader
  grant_cr streaming    stream_writer
  grant_cr analytics    reader
  grant_cr data_science reader
  grant_cr data_science ds_extra

  say "Step 4d: principals (one per service) and their secrets"
  mkdir -p secrets
  mk_principal() { # name principal_role
    local out; out=$(api POST /principals "{\"principal\":{\"name\":\"$1\"},\"credentialRotationRequired\":false}")
    local id sec
    id=$(echo "$out" | jq -r '.credentials.clientId'); sec=$(echo "$out" | jq -r '.credentials.clientSecret')
    echo "$id:$sec" > "secrets/$1.credential"
    api PUT /principals/$1/principal-roles "{\"principalRole\":{\"name\":\"$2\"}}"
    echo "  $1 -> $2  (secret saved to secrets/$1.credential)"
  }
  mk_principal ci_deployer  pipelines
  mk_principal spark_etl    pipelines
  mk_principal flink_stream streaming     # used by the Spark streaming job in this demo
  mk_principal trino_bi     analytics
  mk_principal ds_notebook  data_science
  mk_principal alice        data_eng      # a human engineer: read-only

  say "Fill engine configs from templates"
  sed "s|__SPARK_ETL_CREDENTIAL__|$(cat secrets/spark_etl.credential)|" spark/spark-defaults.conf.template > spark/spark-defaults.conf
  sed "s|__TRINO_BI_CREDENTIAL__|$(cat secrets/trino_bi.credential)|"   trino/retail.properties.template   > trino/retail.properties
  echo "  wrote spark/spark-defaults.conf and trino/retail.properties"
  echo
  echo "Next: docker compose up -d spark trino   then run demo/05_create_tables.sql, then ./polaris-setup.sh phase2"
}

phase2() {
  say "Step 4e: namespace- and table-level grants (tables must exist)"
  api PUT /catalogs/$CATALOG/catalog-roles/stream_writer/grants '{"grant":{"type":"namespace","namespace":["raw"],"privilege":"TABLE_WRITE_DATA"}}'
  for p in TABLE_READ_DATA TABLE_LIST VIEW_LIST VIEW_READ_PROPERTIES NAMESPACE_READ_PROPERTIES; do
    api PUT /catalogs/$CATALOG/catalog-roles/reader/grants "{\"grant\":{\"type\":\"namespace\",\"namespace\":[\"curated\"],\"privilege\":\"$p\"}}"
  done
  # SHOW SCHEMAS needs to list namespace names at catalog level (names only, no data)
  api PUT /catalogs/$CATALOG/catalog-roles/reader/grants '{"grant":{"type":"catalog","privilege":"NAMESPACE_LIST"}}'
  api PUT /catalogs/$CATALOG/catalog-roles/ds_extra/grants '{"grant":{"type":"table","namespace":["pii"],"tableName":"customers","privilege":"TABLE_READ_DATA"}}'

  say "Show the result"
  api GET /catalogs/$CATALOG/catalog-roles/reader/grants | jq .
  echo "Done. Restart Trino so it picks up nothing new is needed; grants apply on the next request."
}

case "${1:-}" in
  phase1) phase1 ;;
  phase2) phase2 ;;
  *) echo "usage: $0 phase1|phase2"; exit 1 ;;
esac
