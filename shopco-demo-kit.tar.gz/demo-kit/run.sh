#!/usr/bin/env bash
# One command per demo step. Run from the demo-kit folder.
#
#   ./run.sh up        start storage + Polaris            (Steps 1-2)
#   ./run.sh setup     catalog, roles, principals          (Steps 3-4)
#   ./run.sh engines   start Spark and Trino
#   ./run.sh 5         create namespaces and tables
#   ./run.sh grants    namespace/table grants              (Step 4, part 2)
#   ./run.sh 6         start the streaming writer (background)
#   ./run.sh 7         Write-Audit-Publish on a branch
#   ./run.sh 7b        incremental read + bookmark tag
#   ./run.sh 8         schema + partition evolution
#   ./run.sh 9         view (Spark) + analyst queries (Trino)
#   ./run.sh 10        tag a training snapshot + PyIceberg read
#   ./run.sh 11        break and roll back
#   ./run.sh 12        GDPR delete (stops the stream first)
#   ./run.sh 13        maintenance = the physical purge
#   ./run.sh 14        credential vending on the wire
#   ./run.sh 15        list the files in the bucket (or browse http://localhost:9001, admin / password)
#   ./run.sh 16        two writers commit to the same table: Polaris rejects the stale one, it retries
#   ./run.sh files     Iceberg's own list of raw.orders data files, to compare with the bucket
#   ./run.sh inspect   what Polaris knows: catalog, roles, grants, principals, namespaces, table schemas
#   ./run.sh sql       open an interactive spark-sql shell
#   ./run.sh trino     open an interactive Trino shell
#   ./run.sh snapshots show the last 5 snapshots of raw.orders
#   ./run.sh status    what is running, is the stream alive
#   ./run.sh stop-stream
#   ./run.sh reset     stop everything and delete all data
set -euo pipefail
cd "$(dirname "$0")"

spark_sql() { docker compose exec -T spark spark-sql --silent -f "/home/iceberg/demo/$1" 2>&1 | grep -v -E '^([0-9/]+ [0-9:]+ )?WARN|setLogLevel|Setting default log level'; }
wait_snapshots() { # wait until raw.orders has at least $1 snapshots (max ~2 min)
  for i in $(seq 1 24); do
    n=$(docker compose exec -T spark spark-sql --silent -e "SELECT count(*) FROM retail.raw.orders.snapshots" 2>/dev/null | grep -E '^[0-9]+$' | tail -1)
    [ "${n:-0}" -ge "$1" ] && return 0
    [ "$i" = 1 ] && echo "waiting for the stream to reach $1 snapshots (one every 30 s) ..."
    sleep 5
  done
  echo "stream has only ${n:-0} snapshots; is it running?  ./run.sh status"; return 1; }
spark_py()  { docker compose exec -T -e SPARK_CRED="$(cat secrets/spark_etl.credential 2>/dev/null)" spark spark-submit "/home/iceberg/demo/$1" 2>&1 | grep -v -E '^(WARN|INFO|[0-9/]+ [0-9:]+ (WARN|INFO)|Pushed|Pushing|Output:| COUNT|Group by|setLogLevel|Post-Scan|Filters evaluated)' | grep -v -E '^[[:space:]]+$' | cat -s; }
banner()    { printf '\n\033[1;33m########## %s ##########\033[0m\n\n' "$*"; }

case "${1:-}" in
  up)
    banner "Steps 1-2: object store, bucket, Polaris"
    docker compose up -d rustfs createbucket polaris
    echo "waiting for Polaris ..."
    for i in $(seq 1 60); do
      curl -sf http://localhost:8182/q/health/ready >/dev/null 2>&1 && { echo "Polaris is ready"; break; }
      sleep 2; [ "$i" = 60 ] && { echo "Polaris not ready after 120 s; run: docker compose logs polaris"; exit 1; }
    done
    docker compose logs createbucket | tail -3
    echo; echo "Bucket browser: http://localhost:9001  (admin / password)" ;;
  setup)   banner "Steps 3-4: catalog, roles, principals"; ./polaris-setup.sh phase1 ;;
  engines)
    banner "Starting Spark and Trino"
    [ -f spark/spark-defaults.conf ] || { echo "run ./run.sh setup first"; exit 1; }
    docker compose up -d spark trino
    echo "waiting for Spark ..."
    for i in $(seq 1 60); do
      docker compose exec -T spark spark-sql --silent -e "SELECT 1" >/dev/null 2>&1 && { echo "Spark is ready"; break; }
      sleep 3; [ "$i" = 60 ] && { echo "Spark not ready; run: docker compose logs spark"; exit 1; }
    done
    echo "waiting for Trino ..."
    for i in $(seq 1 60); do
      curl -sf http://localhost:8090/v1/info | grep -q '"starting":false' && { echo "Trino is ready"; break; }
      sleep 3; [ "$i" = 60 ] && { echo "Trino not ready; run: docker compose logs trino"; exit 1; }
    done ;;
  5)       banner "Step 5: namespaces and tables";            spark_py  05_create_tables.py ;;
  grants)  banner "Step 4 (part 2): namespace and table grants"; ./polaris-setup.sh phase2 ;;
  6)
    banner "Step 6: streaming writer, one commit every 30 s"
    docker compose exec -d spark sh -c "spark-submit /home/iceberg/demo/06_stream_orders.py > /tmp/stream.log 2>&1"
    echo "started in the background (log: /tmp/stream.log in the spark container). Check with:  ./run.sh snapshots" ;;
  7)       banner "Step 7: Write-Audit-Publish";              wait_snapshots 2; spark_py  07_wap_nightly.py ;;
  7b)      banner "Step 7b: incremental read";                wait_snapshots 3; spark_py  07_incremental_read.py ;;
  8)       banner "Step 8: schema and partition evolution";   spark_py  08_evolution.py ;;
  9)
    banner "Step 9a: create a view in Spark";                  spark_py  09_view.py
    banner "Step 9b: analyst queries in Trino";                 ./demo/09_trino_queries.sh ;;
  10)
    banner "Step 10a: tag the training snapshot";              spark_py  10_tag_training_set.py
    banner "Step 10b: PyIceberg reads the tag as ds_notebook"
    docker compose exec -T -e DS_CRED="$(cat secrets/ds_notebook.credential)" spark python3 /home/iceberg/demo/10_pyiceberg_notebook.py ;;
  11)      banner "Step 11: break it, roll back";              spark_py 11_rollback.py ;;
  12)      "$0" stop-stream; banner "Step 12: GDPR delete and purge"; spark_py 12_gdpr_delete.py ;;
  13)      banner "Step 13: maintenance";                      spark_py 13_maintenance.py ;;
  14|A)    banner "Step 14: credential vending on the wire";   ./demo/14_show_vending.sh ;;
  15|B)    banner "Step 15: the files in the bucket";          ./demo/15_inspect_files.sh ;;
  16)      banner "Step 16: two writers, one table";            spark_py 16_concurrent_commit.py ;;
  sql)     docker compose exec spark spark-sql ;;
  trino)   docker compose exec trino trino --catalog retail --schema curated ;;
  files)
    docker compose exec -T spark spark-sql --silent -e \
      "SELECT regexp_extract(file_path, '[^/]+$', 0) AS file, record_count, round(file_size_in_bytes/1024,1) AS kb FROM retail.raw.orders.files WHERE content = 0 ORDER BY file" 2>&1 \
      | grep -v -E '^([0-9/]+ [0-9:]+ )?WARN|setLogLevel|Setting default log level'
    echo "(compare with the bucket: http://localhost:9001 -> shopco-lake/retail/raw/orders/data/, or ./run.sh 15)" ;;
  inspect)
    TOKEN=$(curl -s -X POST http://localhost:8181/api/catalog/v1/oauth/tokens -H 'Polaris-Realm: POLARIS' \
      -d grant_type=client_credentials -d client_id=root -d client_secret=s3cr3t -d scope=PRINCIPAL_ROLE:ALL | jq -r .access_token)
    H=(-H "Authorization: Bearer $TOKEN" -H 'Polaris-Realm: POLARIS')
    M=http://localhost:8181/api/management/v1; C=http://localhost:8181/api/catalog/v1/retail
    banner "Catalog";          curl -s "$M/catalogs/retail" "${H[@]}" | jq '{name, location: .properties."default-base-location", storage: .storageConfigInfo}'
    banner "Catalog roles and their grants"
    for r in $(curl -s "$M/catalogs/retail/catalog-roles" "${H[@]}" | jq -r '.roles[].name'); do
      echo "  $r:"; curl -s "$M/catalogs/retail/catalog-roles/$r/grants" "${H[@]}" | jq -r '.grants[] | "      \(.privilege) on \(.type) \(.namespace // [] | join("."))\(.tableName // "" | if . == "" then "" else "." + . end)"'; done
    banner "Principal roles -> catalog roles"
    for pr in $(curl -s "$M/principal-roles" "${H[@]}" | jq -r '.roles[].name'); do
      echo "  $pr -> $(curl -s "$M/principal-roles/$pr/catalog-roles/retail" "${H[@]}" | jq -r '[.roles[].name] | join(", ")')"; done
    banner "Principals -> principal roles"
    for p in $(curl -s "$M/principals" "${H[@]}" | jq -r '.principals[].name'); do
      echo "  $p -> $(curl -s "$M/principals/$p/principal-roles" "${H[@]}" | jq -r '[.roles[].name] | join(", ")')"; done
    banner "Namespaces, tables and schemas"
    for ns in $(curl -s "$C/namespaces" "${H[@]}" | jq -r '.namespaces[][0]'); do
      for t in $(curl -s "$C/namespaces/$ns/tables" "${H[@]}" | jq -r '.identifiers[].name'); do
        echo "  $ns.$t"
        curl -s "$C/namespaces/$ns/tables/$t" "${H[@]}" | jq -r '"      location:  \(."metadata-location")", (.metadata | "      columns:   \([.schemas[-1].fields[] | "\(.name) \(.type)"] | join(", "))", "      partition: \([."partition-specs"[-1].fields[] | .transform + "(" + .name + ")"] | join(", "))", "      snapshots: \(.snapshots // [] | length)")'
      done
      for v in $(curl -s "$C/namespaces/$ns/views" "${H[@]}" | jq -r '.identifiers[].name'); do echo "  $ns.$v  (view)"; done
    done ;;
  snapshots)
    docker compose exec -T spark spark-sql --silent -e \
      "SELECT committed_at, operation, summary['added-records'] AS added_rows FROM retail.raw.orders.snapshots ORDER BY committed_at DESC LIMIT 5" 2>&1 \
      | grep -v -E '^([0-9/]+ [0-9:]+ )?WARN|setLogLevel|Setting default log level' ;;
  status)
    docker compose ps
    echo
    if docker compose exec -T spark pgrep -f 06_stream_orders >/dev/null 2>&1; then echo "stream: RUNNING"; else
      echo "stream: not running   (restart with ./run.sh 6; it resumes from its checkpoint)"
      echo "last lines of its log:"; docker compose exec -T spark sh -c 'tail -n 8 /tmp/stream.log 2>/dev/null | grep -vE "^\s*at " | cut -c1-160' ; fi ;;
  stop-stream)
    docker compose exec -T spark pkill -f 06_stream_orders 2>/dev/null && echo "stream stopped" || echo "stream was not running" ;;
  reset)
    banner "Removing containers, volumes, secrets and generated configs"
    docker compose down -v
    rm -rf secrets spark/spark-defaults.conf trino/retail.properties ;;
  *) sed -n "2,28p" "$0"; exit 1 ;;
esac
